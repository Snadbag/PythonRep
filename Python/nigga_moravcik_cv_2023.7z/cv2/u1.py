PI = 3.14159265359

r = int(input("Zadaj polomer: "))

print("Polomer je: " + str(r))
print("Obvod je: " + str(2*r*PI))
print("Obsah: " + str(r**2*PI))