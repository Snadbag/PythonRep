str = input("Zadaj string: ")
print(str.replace("\u0020", ""))