n = int(input("Zadaj n: "))
print(f"Na {n} policku bude {str(2**(n-1))} zrniek")