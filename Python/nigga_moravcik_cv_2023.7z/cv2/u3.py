n = int(input("Zadaj pocet riadkov: "))

for i in range(0, n):
	print("*" * (i+1))